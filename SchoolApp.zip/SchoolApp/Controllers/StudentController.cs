﻿using Microsoft.AspNetCore.Mvc;
using SchoolApp.Entities;


namespace SchoolApp.Controllers
{
    public class StudentController : Controller
    {
        private readonly SchoolAppContext schoolAppContext;
        public StudentController()
        {
            schoolAppContext = new SchoolAppContext();
        }
        public IActionResult Index()
        {
            var students=schoolAppContext.Students;
            return View(students);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                schoolAppContext.Students.Add(student);
                schoolAppContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }

        }
        
        public IActionResult GetStudentById(int id)
        {
            var students = schoolAppContext.Students.SingleOrDefault(a => a.StudentId == id);
            return View(students);
        }
        [HttpGet]
        public IActionResult UpdateSkill(string skill)
        {
            var students = schoolAppContext.Students.Where(a => a.Skill == skill);
            return View(students);

        }

        [HttpPost]
        public IActionResult UpdateSkill(Student student)
        {
            if (ModelState.IsValid)
            {
                schoolAppContext.Students.Update(student);
                schoolAppContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }

        }

       public IActionResult GetQualificationById(int id)
{
        var student = schoolAppContext.Students.SingleOrDefault(a => a.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }
            else
            {
                var qualification = student.Qualification;
                return View(qualification);
            }
}
        [HttpGet]
        public IActionResult Delete(int id) { 
        var res = schoolAppContext.Students.SingleOrDefault(a => a.StudentId == id);
        return View(res);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {
            var res = schoolAppContext.Students.Remove(student);
            schoolAppContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
