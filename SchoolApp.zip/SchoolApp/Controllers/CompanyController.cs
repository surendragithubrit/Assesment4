﻿using Microsoft.AspNetCore.Mvc;
using SchoolApp.Entities;

namespace SchoolApp.Controllers
{
    public class CompanyController : Controller
    {
        private readonly SchoolAppContext schoolAppContext;

        public CompanyController()
        {
            schoolAppContext = new SchoolAppContext();
        }
        public IActionResult Index()
        {
            var companies = schoolAppContext.Companies;
            return View(companies);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Company company)
        {
            if (ModelState.IsValid)
            {
                schoolAppContext.Companies.Add(company);
                schoolAppContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }

        }
    }
}
